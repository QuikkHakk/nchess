Usage examples for [lichess' chessground](https://github.com/ornicar/chessground).

```
yarn install
gulp dev
http-server (or any other local http server of your choice)
```

Then browse http://127.0.0.1:8080
